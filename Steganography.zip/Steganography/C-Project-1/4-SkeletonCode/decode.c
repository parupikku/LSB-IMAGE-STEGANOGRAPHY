#include <stdio.h>
#include "common.h"
#include "decode.h"
#include <string.h>
#include "types.h"



Status open_file(DecodeInfo *decInfo)
{
    
    printf("INFO: Opening required files\n");

    // Stego Image file
    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "r");
    printf("INFO: Opened stego_image.bmp\n");

    // Do Error handling
    if (decInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->stego_image_fname);

        return e_failure;
    }

    // No failure return e_success
    return e_success;
}
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
  char* str=strchr(argv[2],'.');
    if(strcmp(str,".bmp")!=0)
    {
        printf("Decoding: ./lsb_steg -d <.bmp file> [output file]\n");
        return e_failure;
    }
    decInfo->stego_image_fname = argv[2];

    if(argv[3]!=NULL)
    {
        char* str=strchr(argv[3],'.');
        if(str!=NULL)
        {
            strncpy(decInfo->secret_file_name,argv[3],str-argv[3]);
            decInfo->secret_file_name[str-argv[3]]='\0';
        }
        else
        {
            strcpy(decInfo->secret_file_name,argv[3]);
        }
    }
    else
    {
        printf("INFO: Output file not mentioned.creating output.txt as default\n");
        strcpy(decInfo->secret_file_name,"output");
    }
}


Status do_decoding(DecodeInfo *decInfo)
{
    /*Open file function call*/
    
    if(open_file(decInfo) == e_failure)//open_file function to open stego image
    {
        return e_failure;
    }

    if(skip_bmp_header(decInfo->fptr_stego_image)==e_failure)// Skip BMP header in the image

    {
        return e_failure;
    }

    /*Store Magic String*/
     printf("INFO: Decoding Magic String Signature\n");
    if( decode_magic_string(decInfo )==e_failure)
    {
        return e_failure;
    }
    printf("INFO: Done\n");


    /*Secret file extension size*/
    if(decode_secret_file_extn_size(decInfo)==e_failure)
    {
        return e_failure;
    }

    /*Secret file extension*/
    printf("INFO: Decoding Output File Extension\n");
    if(decode_secret_file_extn(decInfo)==e_failure)
    {
        return e_failure;
    }
     //printf("INFO: Done\n");


    /*Secret file size*/
    printf("INFO: Decoding output.txt File Size \n");
    if( decode_secret_file_size(decInfo) == e_failure )
    {
        return e_failure;
    }
    printf("INFO: Done\n");

    //Secret file data
     printf("INFO: Decoding output.txt File Data\n");
    if( decode_secret_file_data(decInfo) == e_failure )
    {
    return e_failure;
    }
    printf("INFO: Done\n");


    return e_success;

}

/*skip bmp header*/
Status skip_bmp_header(FILE *fptr_stego_image)
{
    fseek(fptr_stego_image,54,SEEK_SET);//skip first 54 bytes
    return e_success;
}

/*decode magic_string*/
Status decode_magic_string(DecodeInfo *decInfo)
{
    char image_buffer[8];// Buffer to hold 8 bytes of image data
    char decoded_magic_string[20];// Buffer to store decoded magic string     
    char str[20];// Buffer to store user-provided magic string
    //Read magic string from the user
    printf("Enter the magic string: ");
    scanf("%s",str);// Read user input
    

    /*for loop data length times */
    for(int i=0;i<2;i++)
    {

    /*read 8 bytes from src image file data */
    fread(image_buffer,8,1,decInfo->fptr_stego_image);

    /*call the lsb_to_byte(image_buffer)*/
    decoded_magic_string[i]=decode_lsb_to_byte(image_buffer);
    }
    decoded_magic_string[2]='\0';
    //printf("Magic String is %s\n",decoded_magic_string);
 /*Comparing the user entered magic string and  decoded magic string are same*/
    if (strcmp(decoded_magic_string,str)!=0)
    {
        
        return e_failure;
    }
    
    return e_success;
    
}

 //Calling lsb to byte function 
char decode_lsb_to_byte(char *image_buffer)
{
    char ch=0;
    char bit;
    /* Run loop data length times */
    for(int i=0;i<8;i++)
    {
        bit=(unsigned)(image_buffer[i] & 1) <<(7-i);
        ch=bit|ch;

    }
    return ch;

}



/* Decoding secret file extension size */
Status decode_secret_file_extn_size(DecodeInfo *decInfo)
{
    char buffer[32];
    /*Reading from stego image*/
    fread(buffer,32,1,decInfo->fptr_stego_image);
    int extn_size=decode_lsb_to_int(buffer);
    //printf("Extension size is %d\n",extn_size);

}

/* Calling lsb to int function */
uint decode_lsb_to_int(char *image_buffer)
{
    int data=0;
    int bit;
    for(int i=0;i<32;i++)
    {
        bit=(unsigned)(image_buffer[i] & 1)<<(31-i);

        data=bit|data;

    }
    return data;
}

/*secret_file_extension*/
Status decode_secret_file_extn(DecodeInfo *decInfo)
{
    char image_buffer[8];// Buffer to hold 8 bits of image data
    char str[20]; // Buffer to store the decoded file extension

    int i=0;
    for(i=0;i<4;i++)
    {
        fread(image_buffer,8,1,decInfo->fptr_stego_image);
        str[i]=decode_lsb_to_byte(image_buffer);
    }
    str[i]='\0';
    printf("INFO: DONE\n");

    strcat(decInfo->secret_file_name,str);// merge the decoded extension to the secret file name
    printf("Extension is %s\n",str);
    //printf("%s\n",decInfo->secret_file_name);

    decInfo->fptr_output=fopen(decInfo->secret_file_name,"w");
    printf("INFO: Opened output.txt");
    printf("INFO:Done. Opened all required files\n");
    if(decInfo->fptr_output==NULL)
    {
        printf("File not Exist\n");
        return e_failure;
    }
    return e_success;
}

/*secret file size*/
Status decode_secret_file_size(DecodeInfo *decInfo)
{
    char buffer[32];// Buffer to hold 32 bits
    uint secret_size;

   
    fread(buffer,32,1,decInfo->fptr_stego_image);
    secret_size=decode_lsb_to_int(buffer);

   decInfo->size_secret_file=secret_size;
    //printf("Secret file size is %ld\n", decInfo->size_secret_file);

    return e_success;

}

/*secret file data*/
Status decode_secret_file_data(DecodeInfo *decInfo)
{
    char image_buffer[8];// Buffer to hold 8 bits of image data
    char ch;
    for(int i=0;i< decInfo->size_secret_file;i++)
    {
    fread(image_buffer,8,1,decInfo->fptr_stego_image);// Read 8 bits from the image
    ch=decode_lsb_to_byte(image_buffer);
    fwrite(&ch,1,1,decInfo->fptr_output); // Write the decoded byte to the output file
    }

    fclose(decInfo->fptr_output);
    return e_success;

}
