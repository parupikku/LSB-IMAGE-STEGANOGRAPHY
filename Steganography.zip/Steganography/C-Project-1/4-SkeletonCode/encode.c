#include <stdio.h>
#include "common.h"
#include "encode.h"
#include <string.h>
#include "types.h"

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}
/* get file size*/
uint get_file_size(FILE *fptr)
{
    // Go to the end of the file
    fseek(fptr, 0, SEEK_END);

    // Get the current position in the file, which is the size
    long size = ftell(fptr);

    // Return to the beginning of the file
    rewind(fptr);

    // Return the size
    return size;


}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
/*Read and validate*/
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    char *str = strchr(argv[2],'.');
    if(strcmp(str,".bmp")!=0)
    {
        printf("Encoding: ./lsb_steg -e <.bmp file> <.txt file> [output file]\n");
        return e_failure;
    }
    encInfo->src_image_fname = argv[2];


    char *str1=strchr(argv[3],'.');
    if(str1[1]>='A' && str1[1]<='Z' || str1[1]>='a' && str1[1]<='z')
    {
        encInfo->secret_fname = argv[3];
    }
    else
    {
         printf("Encoding: ./lsb_steg -e <.bmp file> <.txt file> [output file]\n");
        return e_failure;

    }
 if(argv[4]!=NULL)
    {
        char *str2=strchr(argv[4],'.');
        
            if(strcmp(str2,".bmp")==0)
            {
                encInfo->stego_image_fname = argv[4];
            }
            else
            {
                printf("Encoding: ./lsb_steg -e <.bmp file> <.txt file> [output file]\n");
                return e_failure;                
            }
        
    }
    else
    {
        printf("INFO: Output file not mentioned. Creating steged_img.bmp as default\n");
        encInfo->stego_image_fname = "stego_img.bmp";
    }
}
/* open the files*/
Status open_files(EncodeInfo *encInfo)
{
    // Src Image file in read mode
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
     printf("INFO: Opened beautiful.bmp\n");

    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

        return e_failure;
    }

    // Secret file in read mode
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
      printf("INFO: Opened secret.txt\n");

    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

        return e_failure;
    }

    // Stego Image file in write mode
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    printf("INFO: Opened stego.bmp\n");

    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

        return e_failure;
    }
     printf("Done\n");

    // No failure return e_success
    return e_success;
}


/* encoding process*/
Status do_encoding(EncodeInfo *encInfo)
{
    /*Open file function call*/
    if(open_files(encInfo) == e_failure)
    {
        return e_failure;
    }
    printf("INFO: ## Encoding Procedure Started ##\n");
    /*Check Capacity function call*/
    if (check_capacity(encInfo) == e_failure)
    {
        return e_failure;
    }
    // Copy BMP header from source to stego image
    printf("INFO: Copying Image Header\n");
    if( copy_bmp_header(encInfo->fptr_src_image,encInfo->fptr_stego_image)==e_failure)
    {
        return e_failure;
    }
    printf("INFO: Done\n");


    /*Store Magic String*/
    printf("INFO: Encoding Magic String Signature\n");
    if( encode_magic_string(MAGIC_STRING , encInfo )==e_failure)
    {
        return e_failure;
    }
    printf("INFO: Done\n");

    /*Secret file extension size*/
   printf("INFO: Checking for secret.txt size\n");
    if(encode_secret_file_extn_size(strlen(encInfo->extn_secret_file),encInfo)==e_failure)
    {
        return e_failure;
    }
    printf("INFO: Done. Not Empty\n");


    /*Secret file extension*/
    printf("INFO: Encoding secret.txt File Extension\n");
    if(encode_secret_file_extn(encInfo->extn_secret_file,encInfo)==e_failure)
    {
        return e_failure;
    }
    printf("INFO: Done\n");


    /*Secret file size*/
     printf("INFO: Encoding secret.txt File Size\n");
    if( encode_secret_file_size(encInfo->size_secret_file,encInfo) == e_failure )
    {
        return e_failure;
    }
    printf("INFO: Done\n");


    /*Secret file data*/
       printf("INFO: Encoding secret.txt File Data\n");
    if( encode_secret_file_data(encInfo) == e_failure )
    {
    return e_failure;
    }
    printf("INFO: Done\n");


    /*Copy remaining image data*/
    printf("INFO: Copying Left Over Data\n");
    if(copy_remaining_img_data(encInfo->fptr_src_image,encInfo->fptr_stego_image) == e_failure )
    {
    return e_failure;
    }
    printf("INFO: Done\n");


    return e_success;


}
/* Check if the image has enough capacity to hold secret data */
Status check_capacity(EncodeInfo *encInfo)
{
    /*find image size (bmp file size)*/
    uint image_size = get_image_size_for_bmp(encInfo->fptr_src_image);

    /*find secret file size*/
    uint secret_file_size = get_file_size(encInfo->fptr_secret);
    encInfo->size_secret_file=secret_file_size;

    /*Magic String length*/
    uint magic_string_length = strlen(MAGIC_STRING);

    /*Secret file extension size*/
    uint secret_file_extn_size = MAX_FILE_SUFFIX;

    /*Secret file extension */
    uint secret_file_extn = strlen(encInfo->extn_secret_file);

    /* Size of the BMP header */
    uint bmp_header_size = 54;

    /*header + (magic_string_length + secret_file_extn_size + secret_file_extn + sec_file_size) * 8) */
    uint data_size = bmp_header_size + ((magic_string_length + secret_file_extn_size + secret_file_extn+ 4 + secret_file_size) * 8);

    /*compare with image size*/

    if(image_size >= data_size)
    {
    /*image size greater than data size */
            /* e_success */
        return e_success;
    }
    else
    {
    /*image size is lesser than data size*/
            /* e_failure */
        return e_failure;
    }
}


/* Copy the BMP header from the source image to the stego image */
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    /*Rewind the both src and dest file pointers */
    rewind(fptr_src_image);
    rewind(fptr_dest_image);
    char buffer[54];

    /*read 54 bytes data from src file */
    fread(buffer,54,1,fptr_src_image);

    /* Write the 54 bytes to dest file*/
    fwrite(buffer,54,1,fptr_dest_image);
    /*return e_success*/

    return e_success;
}


/* Store Magic String */

Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    char image_buffer[8];

    int magic_length=strlen(magic_string);

    /*for loop data length times */
    for(int i=0;i<magic_length;i++)
    {

    /*read 8 bytes from src image file data */
    fread(image_buffer,8,1,encInfo->fptr_src_image);

    /*call the byte_to_lsb(magic_string[i],image_buffer)*/
    encode_byte_to_lsb(magic_string[i],image_buffer);

    /*write into stego image file*/
    fwrite(image_buffer,8,1,encInfo->fptr_stego_image);
    }

    return e_success;
    
}
/*byte to lsb*/
Status encode_byte_to_lsb(char data,char *image_buffer)
{
    
    char ch;
    for(int i=0;i<8;i++)
    {
    //clear the LSB of image_buffer
    image_buffer[i]=image_buffer[i] & 0xFE;

    //Get 1 bit from MSB of data

    ch = ((unsigned)(data & (1<<(7-i))) >> (7-i));

    //merge 1 bit of data and image_buffer

    image_buffer[i] = image_buffer[i] |  ch;
    }
    return e_success;

}
/* Encode the size of the secret file extension */
Status encode_secret_file_extn_size(uint extn_size,EncodeInfo *encInfo)
{
    char buffer[32];
    fread(buffer,32,1,encInfo->fptr_src_image);
 
    // Encode the extension size (4 bytes) into the image buffer using LSB
    encode_int_to_lsb(extn_size,buffer);

    fwrite(buffer,32,1,encInfo->fptr_stego_image);

    return e_success;
}

/*int to lsb*/
Status encode_int_to_lsb(int data,char *image_buffer)
{
    
    char ch;
    for(int i=0;i<32;i++)
    {
    //clear the LSB of image_buffer
    image_buffer[i]=image_buffer[i] & 0xFE;

    //Get 1 bit from MSB of data

    ch = ((unsigned)(data & (1<<(31-i))) >> (31-i));

    //merge 1 bit of data and image_buffer

    image_buffer[i] = image_buffer[i] |  ch;
    }
    return e_success;
}


/*Encode secret file extention */
Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    char extn_buffer[8];// Buffer to store 8 bytes from the image

    int msg_length=strlen(file_extn);// Length of the file extension

    // Loop through each character of the file extension
    for(int i=0;i<msg_length;i++)
    {
        fread(extn_buffer,8,1,encInfo->fptr_src_image);

       // Encode one character of the file extension into the LSBs
        encode_byte_to_lsb(file_extn[i],extn_buffer);

        fwrite(extn_buffer,8,1,encInfo->fptr_stego_image);
    }
    return e_success;
}

/*Encode Secret file Size*/
Status encode_secret_file_size(long size_secret_file, EncodeInfo *encInfo)
{
    char buffer[32];// Buffer to store 32 bytes from the image
    // Read 32 bytes from the source image into the buffer
    fread(buffer,32,1,encInfo->fptr_src_image);
    // Encode the secret file size into the LSBs of 32 bytes 
    encode_int_to_lsb(size_secret_file,buffer);
    // Write the modified 32-byte buffer into the stego image
    fwrite(buffer,32,1,encInfo->fptr_stego_image);
    

    return e_success;

}

/* Encode secret file data into the image */
Status encode_secret_file_data(EncodeInfo *encInfo)
{

    char secret_char;
    char secret_buffer[8];// Buffer to store 8 bytes 

    while(fread(&secret_char,1,1,encInfo->fptr_secret)>0)
    {
        fread(secret_buffer,8,1,encInfo->fptr_src_image);

        encode_byte_to_lsb(secret_char,secret_buffer);

        fwrite(secret_buffer,8,1,encInfo->fptr_stego_image);
    }
    return e_success;
}

/* Copy the remaining unencoded image data */
Status copy_remaining_img_data(FILE *fptr_src,FILE *fptr_dest)
{
    char byte;
    while(fread(&byte,1,1,fptr_src)>0)
    {
        fwrite(&byte,1,1,fptr_dest);
    }
    return e_success;
}



