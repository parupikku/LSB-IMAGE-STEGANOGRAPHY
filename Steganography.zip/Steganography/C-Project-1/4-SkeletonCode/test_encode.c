#include <stdio.h>
#include<string.h>
#include "encode.h"
#include "decode.h"
#include "types.h"

int main(int argc,char *argv[])
{
    EncodeInfo encInfo;
    DecodeInfo decInfo;
    uint img_size;


if(check_operation_type(argv[1])==e_encode)
{
    //encoding
    // Fill with sample filenames
    //encInfo.src_image_fname = argv[2];
    //encInfo.secret_fname = argv[3];
    //encInfo.stego_image_fname = "stego_img.bmp";
    if (argc < 4 || argc > 5) 
    {
          printf("Error No. of argument should be 4 or 5");
           return e_failure;
     }
    if(read_and_validate_encode_args(argv,&encInfo)==e_failure)
    {
        return e_failure;
    }

    strcpy(encInfo.extn_secret_file,strchr(argv[3],'.'));
    printf("Selected Encoding\n");
    if(do_encoding(&encInfo)==e_success)
    {
        printf("Encoding is done Successfully\n");
    }
}
else if(check_operation_type(argv[1])==e_decode)
{
    //decoding
    //decInfo.stego_image_fname = argv[2];
    //strcpy(decInfo.secret_file_name,"output");
   
    if (argc < 3|| argc > 4) 
    {
          printf("Error No. of argument should be 3 or 2");
           return e_failure;
     }
    if(read_and_validate_decode_args(argv, &decInfo)==e_failure)
    {
        return e_failure;
    }
    printf("Selected Decoding\n");
    if(do_decoding(&decInfo)==e_success)
    {
        printf("Decoding is done Successfully\n");
    }
}
else
{
    //invalid
    printf("Invaliid Operation");
}


}

OperationType check_operation_type(char* argv)
{
    if(strcmp(argv,"-e")==0)
    {
        return e_encode;
    }
    else if(strcmp(argv,"-d")==0)
    {
        return e_decode;
    }
    else
    {
        return e_unsupported;
    }
}

